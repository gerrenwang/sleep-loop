const express = require("express");
const fetch = require("node-fetch");
const app = express();

app.use(express.json());

const MAPBOX_KEY = process.env.MAPBOX_KEY;

// Generate loop route
app.post("/loop", async (req, res) => {
  const { lat, lon, minutes } = req.body;
  const distanceKm = (minutes / 60) * 50; // assume 50km/h avg
  const radius = distanceKm / 2;

  const angle = Math.random() * Math.PI * 2;
  const offsetLat = lat + (radius / 111) * Math.cos(angle);
  const offsetLon = lon + (radius / (111 * Math.cos(lat * Math.PI/180))) * Math.sin(angle);

  const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${lon},${lat};${offsetLon},${offsetLat};${lon},${lat}?geometries=geojson&access_token=${MAPBOX_KEY}`;

  const response = await fetch(url);
  const data = await response.json();

  res.json(data);
});

app.listen(3000, () => {
  console.log("Sleep Loop server running on port 3000");
});
